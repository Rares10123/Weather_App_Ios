
import Foundation


enum weatherImage: String {
    case clearsky = "Clear sky"
    case fewclouds = "Few clouds"
    case scatteredclouds = "Scattered clouds"
    case brokenclouds = "Broken clouds"
    case showerrain = "Shower rain"
    case rain = "Rainy"
    case thunderstorm = "Thunder storm"
    case snow = "Snowy"
    case mist = "Mist"
}
