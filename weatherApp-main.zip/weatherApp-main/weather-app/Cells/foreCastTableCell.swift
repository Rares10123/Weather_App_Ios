
import UIKit

class foreCastTableCell: UITableViewCell {
    static let ID: String = "forecastCell"
    @IBOutlet var weatherImage: UIImageView!
    
    @IBOutlet var timeLbl: UILabel!
    
    @IBOutlet var conditionLbl: UILabel!
    
    @IBOutlet var degreeLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
